#!/bin/bash
if [ $# -ne 1 ]; then
	echo "usage: " $0 "<n:1~50>"
	exit
fi

var=$1

if [[ $var -lt 1 || $var -gt 50 ]]; then
	echo "input integer should be between 1 and 50"
	exit
fi

printf "Here is your list:\n%d, " $var
len=1
while [  $var -ne 1 ]; do
	#((r=var%2))
	let r=$var%2
	if [ $r -eq 1 ]; then
		let var=var*3+1 
	else
		let var=var/2 
	fi
	let len++
	printf "%d, " $var
done
echo
echo "len=$len"
