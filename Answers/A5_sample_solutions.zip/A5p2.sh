#!/bin/bash

for i in {1..4}
	do
	for j in {1..7}
		do
			((v = $i*$j))
			echo "$i * $j = $v"
		done
	done
