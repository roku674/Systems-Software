#!/bin/bash

function printEquation {
	((v = $1*$2))
	echo "$1 * $2 = $v"
}
for i in {1..4}
	do
	for j in {1..7}
		do
			printEquation $i $j
		done
	done
