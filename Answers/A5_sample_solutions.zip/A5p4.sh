#!/bin/bash
#you can call this script with "bash A5p4.sh Collatz"

if [ -z $1 ]; then
	echo "usage: " $0 "<your_Cpp_Program>"
	exit
fi

for i in {25..40}
	do
		echo "sequence for $i"
		$1 $i #you may replace $1 with your C++ program name here; in this way you do not need to supply a command line argument to this script
		echo
	done
